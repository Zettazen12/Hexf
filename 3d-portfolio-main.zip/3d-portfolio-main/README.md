# 3d-portfolio

Personal Portfolio website designed using ThreeJS

Install Dependencies

```sh
npm install
```

Start the development server

```sh
npm run dev
```

Preview: https://chimerical-sawine-e5d69e.netlify.app/
